#include "d:\lang\c\robot\ROBOT.H"
/* An alternate way to solve the maze, using functions */

DEFINE(CHECK_PELLET)
   IF PELLET
      BEGIN
      F
      TAKE
      WAIT
      STOP
      END
   ELSE
       F
   END_DEFINE

DEFINE(GO_RIGHT)
   R
   IF BLOCKED
      BEGIN
      L
      RETURN_FALSE
      END
   CALL(CHECK_PELLET)
   F
   RETURN_TRUE
   END_DEFINE

DEFINE(GO_FORWARD)
   IF BLOCKED
      RETURN_FALSE
   CALL(CHECK_PELLET)
   F
   RETURN_TRUE
   END_DEFINE

DEFINE(GO_LEFT)
   L
   IF BLOCKED
      BEGIN
      R
      RETURN_FALSE
      END
   CALL(CHECK_PELLET)
   F
   RETURN_TRUE
   END_DEFINE

DEFINE(TURN_AROUND)
   R
   R
   F
   END_DEFINE


START_PROGRAM

LOAD("d:/lang/c/robot/MAZE5")
SPEED(10)

/*event driven code, where the robot ask me what to do*/


WHILE NOT PELLET
IF NOT TRUE(GO_RIGHT)
   IF NOT TRUE(GO_FORWARD)
      IF NOT TRUE (GO_LEFT)
         CALL(TURN_AROUND)
F
TAKE
WAIT
END_PROGRAM
